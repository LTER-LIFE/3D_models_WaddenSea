*(replaced by* :ref:`avail_easyconfig_params` *)*
