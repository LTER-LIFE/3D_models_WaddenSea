
.. _basic_usage_easyblocks:

List of easyblocks
==================

The list of available easyblocks can easily be obtained as follows:

.. include:: version-specific/eb_list_easyblocks.txt

