*(replaced by* :ref:`eb_help` *)*
