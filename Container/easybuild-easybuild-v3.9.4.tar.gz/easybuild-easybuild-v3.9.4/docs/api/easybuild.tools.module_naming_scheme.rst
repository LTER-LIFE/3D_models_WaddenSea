easybuild.tools.module\_naming\_scheme package
==============================================

Submodules
----------

.. toctree::

   easybuild.tools.module_naming_scheme.categorized_hmns
   easybuild.tools.module_naming_scheme.categorized_mns
   easybuild.tools.module_naming_scheme.easybuild_mns
   easybuild.tools.module_naming_scheme.hierarchical_mns
   easybuild.tools.module_naming_scheme.migrate_from_eb_to_hmns
   easybuild.tools.module_naming_scheme.mns
   easybuild.tools.module_naming_scheme.toolchain
   easybuild.tools.module_naming_scheme.utilities

Module contents
---------------

.. automodule:: easybuild.tools.module_naming_scheme
    :members:
    :undoc-members:
    :show-inheritance:
