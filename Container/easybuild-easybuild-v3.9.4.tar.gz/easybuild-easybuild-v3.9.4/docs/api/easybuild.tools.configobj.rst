easybuild.tools.configobj module
================================

.. automodule:: easybuild.tools.configobj
    :members:
    :undoc-members:
    :show-inheritance:
