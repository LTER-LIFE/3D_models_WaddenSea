easybuild.tools.module\_naming\_scheme.hierarchical\_mns module
===============================================================

.. automodule:: easybuild.tools.module_naming_scheme.hierarchical_mns
    :members:
    :undoc-members:
    :show-inheritance:
