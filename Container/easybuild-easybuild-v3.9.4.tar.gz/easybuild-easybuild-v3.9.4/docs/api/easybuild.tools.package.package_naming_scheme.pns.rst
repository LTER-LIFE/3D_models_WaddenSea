easybuild.tools.package.package\_naming\_scheme.pns module
==========================================================

.. automodule:: easybuild.tools.package.package_naming_scheme.pns
    :members:
    :undoc-members:
    :show-inheritance:
