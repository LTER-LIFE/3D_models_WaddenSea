easybuild.toolchains.intel\-para module
=======================================

.. automodule:: easybuild.toolchains.intel-para
    :members:
    :undoc-members:
    :show-inheritance:
