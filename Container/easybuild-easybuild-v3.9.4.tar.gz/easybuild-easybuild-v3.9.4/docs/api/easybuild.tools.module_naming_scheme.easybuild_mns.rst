easybuild.tools.module\_naming\_scheme.easybuild\_mns module
============================================================

.. automodule:: easybuild.tools.module_naming_scheme.easybuild_mns
    :members:
    :undoc-members:
    :show-inheritance:
