easybuild.framework.easyconfig.licenses module
==============================================

.. automodule:: easybuild.framework.easyconfig.licenses
    :members:
    :undoc-members:
    :show-inheritance:
