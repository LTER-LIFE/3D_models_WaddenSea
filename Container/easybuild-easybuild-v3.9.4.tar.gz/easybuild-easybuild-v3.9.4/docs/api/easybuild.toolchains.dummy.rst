easybuild.toolchains.dummy module
=================================

.. automodule:: easybuild.toolchains.dummy
    :members:
    :undoc-members:
    :show-inheritance:
