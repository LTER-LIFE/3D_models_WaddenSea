easybuild.tools.variables module
================================

.. automodule:: easybuild.tools.variables
    :members:
    :undoc-members:
    :show-inheritance:
