easybuild.toolchains.mpi.psmpi module
=====================================

.. automodule:: easybuild.toolchains.mpi.psmpi
    :members:
    :undoc-members:
    :show-inheritance:
