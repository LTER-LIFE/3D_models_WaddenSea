easybuild.toolchains.linalg.gotoblas module
===========================================

.. automodule:: easybuild.toolchains.linalg.gotoblas
    :members:
    :undoc-members:
    :show-inheritance:
