easybuild.tools.version module
==============================

.. automodule:: easybuild.tools.version
    :members:
    :undoc-members:
    :show-inheritance:
