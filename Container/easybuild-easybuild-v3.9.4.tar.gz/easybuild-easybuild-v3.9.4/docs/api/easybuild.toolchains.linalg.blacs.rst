easybuild.toolchains.linalg.blacs module
========================================

.. automodule:: easybuild.toolchains.linalg.blacs
    :members:
    :undoc-members:
    :show-inheritance:
