easybuild.tools.containers.singularity module
=============================================

.. automodule:: easybuild.tools.containers.singularity
    :members:
    :undoc-members:
    :show-inheritance:
