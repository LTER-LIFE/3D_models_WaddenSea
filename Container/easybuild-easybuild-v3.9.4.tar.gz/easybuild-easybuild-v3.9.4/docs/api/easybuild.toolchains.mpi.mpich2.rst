easybuild.toolchains.mpi.mpich2 module
======================================

.. automodule:: easybuild.toolchains.mpi.mpich2
    :members:
    :undoc-members:
    :show-inheritance:
