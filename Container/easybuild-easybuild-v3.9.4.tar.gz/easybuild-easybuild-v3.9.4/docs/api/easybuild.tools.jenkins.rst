easybuild.tools.jenkins module
==============================

.. automodule:: easybuild.tools.jenkins
    :members:
    :undoc-members:
    :show-inheritance:
