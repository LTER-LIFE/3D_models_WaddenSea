easybuild.framework.extensioneasyblock module
=============================================

.. automodule:: easybuild.framework.extensioneasyblock
    :members:
    :undoc-members:
    :show-inheritance:
