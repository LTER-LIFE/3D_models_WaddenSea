easybuild.tools.toolchain.mpi module
====================================

.. automodule:: easybuild.tools.toolchain.mpi
    :members:
    :undoc-members:
    :show-inheritance:
