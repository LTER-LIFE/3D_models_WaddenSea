easybuild.toolchains.linalg.intelmkl module
===========================================

.. automodule:: easybuild.toolchains.linalg.intelmkl
    :members:
    :undoc-members:
    :show-inheritance:
