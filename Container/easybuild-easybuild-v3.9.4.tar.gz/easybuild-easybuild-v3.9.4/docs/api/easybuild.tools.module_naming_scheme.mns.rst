easybuild.tools.module\_naming\_scheme.mns module
=================================================

.. automodule:: easybuild.tools.module_naming_scheme.mns
    :members:
    :undoc-members:
    :show-inheritance:
