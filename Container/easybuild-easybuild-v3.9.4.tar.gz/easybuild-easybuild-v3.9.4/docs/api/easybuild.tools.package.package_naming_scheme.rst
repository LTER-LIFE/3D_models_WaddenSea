easybuild.tools.package.package\_naming\_scheme package
=======================================================

Submodules
----------

.. toctree::

   easybuild.tools.package.package_naming_scheme.easybuild_pns
   easybuild.tools.package.package_naming_scheme.pns

Module contents
---------------

.. automodule:: easybuild.tools.package.package_naming_scheme
    :members:
    :undoc-members:
    :show-inheritance:
