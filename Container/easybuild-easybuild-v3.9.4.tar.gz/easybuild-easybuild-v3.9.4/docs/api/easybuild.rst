.. _easybuild_api_top:

easybuild package
=================

Subpackages
-----------

.. toctree::

    easybuild.framework
    easybuild.toolchains
    easybuild.tools

Submodules
----------

.. toctree::

   easybuild.main

Module contents
---------------

.. automodule:: easybuild
    :members:
    :undoc-members:
    :show-inheritance:
