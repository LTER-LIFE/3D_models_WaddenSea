easybuild.toolchains.mpi.mpich module
=====================================

.. automodule:: easybuild.toolchains.mpi.mpich
    :members:
    :undoc-members:
    :show-inheritance:
