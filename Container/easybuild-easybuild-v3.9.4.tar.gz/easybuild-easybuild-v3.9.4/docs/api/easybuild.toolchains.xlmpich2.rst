easybuild.toolchains.xlmpich2 module
====================================

.. automodule:: easybuild.toolchains.xlmpich2
    :members:
    :undoc-members:
    :show-inheritance:
