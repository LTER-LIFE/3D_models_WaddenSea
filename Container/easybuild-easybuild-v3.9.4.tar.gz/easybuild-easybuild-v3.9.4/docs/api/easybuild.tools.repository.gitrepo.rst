easybuild.tools.repository.gitrepo module
=========================================

.. automodule:: easybuild.tools.repository.gitrepo
    :members:
    :undoc-members:
    :show-inheritance:
