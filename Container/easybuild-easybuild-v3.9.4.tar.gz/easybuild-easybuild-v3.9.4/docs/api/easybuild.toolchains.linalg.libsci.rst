easybuild.toolchains.linalg.libsci module
=========================================

.. automodule:: easybuild.toolchains.linalg.libsci
    :members:
    :undoc-members:
    :show-inheritance:
