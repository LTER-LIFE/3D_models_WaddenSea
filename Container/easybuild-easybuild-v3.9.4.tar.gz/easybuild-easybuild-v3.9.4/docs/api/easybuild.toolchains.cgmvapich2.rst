easybuild.toolchains.cgmvapich2 module
======================================

.. automodule:: easybuild.toolchains.cgmvapich2
    :members:
    :undoc-members:
    :show-inheritance:
