easybuild.tools.module\_naming\_scheme.categorized\_hmns module
===============================================================

.. automodule:: easybuild.tools.module_naming_scheme.categorized_hmns
    :members:
    :undoc-members:
    :show-inheritance:
