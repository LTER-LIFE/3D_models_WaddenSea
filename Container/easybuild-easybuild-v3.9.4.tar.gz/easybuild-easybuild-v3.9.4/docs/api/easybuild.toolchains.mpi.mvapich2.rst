easybuild.toolchains.mpi.mvapich2 module
========================================

.. automodule:: easybuild.toolchains.mpi.mvapich2
    :members:
    :undoc-members:
    :show-inheritance:
