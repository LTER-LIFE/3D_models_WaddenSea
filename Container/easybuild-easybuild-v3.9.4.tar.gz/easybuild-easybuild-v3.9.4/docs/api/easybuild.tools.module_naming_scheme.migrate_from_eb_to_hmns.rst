easybuild.tools.module\_naming\_scheme.migrate\_from\_eb\_to\_hmns module
=========================================================================

.. automodule:: easybuild.tools.module_naming_scheme.migrate_from_eb_to_hmns
    :members:
    :undoc-members:
    :show-inheritance:
