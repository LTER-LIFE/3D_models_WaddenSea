easybuild.toolchains.intel module
=================================

.. automodule:: easybuild.toolchains.intel
    :members:
    :undoc-members:
    :show-inheritance:
