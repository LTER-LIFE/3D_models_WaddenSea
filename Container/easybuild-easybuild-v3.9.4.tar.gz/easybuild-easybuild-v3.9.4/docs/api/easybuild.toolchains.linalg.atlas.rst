easybuild.toolchains.linalg.atlas module
========================================

.. automodule:: easybuild.toolchains.linalg.atlas
    :members:
    :undoc-members:
    :show-inheritance:
