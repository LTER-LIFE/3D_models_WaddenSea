easybuild.tools.module\_naming\_scheme.utilities module
=======================================================

.. automodule:: easybuild.tools.module_naming_scheme.utilities
    :members:
    :undoc-members:
    :show-inheritance:
