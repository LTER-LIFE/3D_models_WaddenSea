easybuild.framework.extension module
====================================

.. automodule:: easybuild.framework.extension
    :members:
    :undoc-members:
    :show-inheritance:
