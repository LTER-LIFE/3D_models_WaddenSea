easybuild.toolchains.mpi.openmpi module
=======================================

.. automodule:: easybuild.toolchains.mpi.openmpi
    :members:
    :undoc-members:
    :show-inheritance:
