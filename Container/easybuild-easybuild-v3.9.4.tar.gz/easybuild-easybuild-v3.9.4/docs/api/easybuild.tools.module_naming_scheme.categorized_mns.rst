easybuild.tools.module\_naming\_scheme.categorized\_mns module
==============================================================

.. automodule:: easybuild.tools.module_naming_scheme.categorized_mns
    :members:
    :undoc-members:
    :show-inheritance:
