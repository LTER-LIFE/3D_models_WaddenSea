easybuild.toolchains.linalg.flame module
========================================

.. automodule:: easybuild.toolchains.linalg.flame
    :members:
    :undoc-members:
    :show-inheritance:
