easybuild.tools.build\_details module
=====================================

.. automodule:: easybuild.tools.build_details
    :members:
    :undoc-members:
    :show-inheritance:
