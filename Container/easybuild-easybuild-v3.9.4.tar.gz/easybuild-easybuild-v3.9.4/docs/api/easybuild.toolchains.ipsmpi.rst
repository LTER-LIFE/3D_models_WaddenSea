easybuild.toolchains.ipsmpi module
==================================

.. automodule:: easybuild.toolchains.ipsmpi
    :members:
    :undoc-members:
    :show-inheritance:
