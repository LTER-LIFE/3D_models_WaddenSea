easybuild.tools.module\_generator module
========================================

.. automodule:: easybuild.tools.module_generator
    :members:
    :undoc-members:
    :show-inheritance:
