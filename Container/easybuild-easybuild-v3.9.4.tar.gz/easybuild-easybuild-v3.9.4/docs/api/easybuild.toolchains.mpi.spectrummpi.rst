easybuild.toolchains.mpi.spectrummpi module
===========================================

.. automodule:: easybuild.toolchains.mpi.spectrummpi
    :members:
    :undoc-members:
    :show-inheritance:
