easybuild.tools.package.package\_naming\_scheme.easybuild\_pns module
=====================================================================

.. automodule:: easybuild.tools.package.package_naming_scheme.easybuild_pns
    :members:
    :undoc-members:
    :show-inheritance:
