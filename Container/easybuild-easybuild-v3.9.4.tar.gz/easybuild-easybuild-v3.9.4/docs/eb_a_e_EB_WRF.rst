
.. _eb_a_e_EB_WRF:

Available easyconfig parameters for EB_WRF
==========================================

Overview of easyconfig parameters, including those specific to the easyblock for WRF (indicated with ``(*)``):

.. include:: version-specific/eb_a_e_EB_WRF.txt

