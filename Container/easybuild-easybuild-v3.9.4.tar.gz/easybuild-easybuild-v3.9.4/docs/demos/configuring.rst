.. _demo_configuring:

Demo: configuring EasyBuild
=============================

(see also :ref:`configuring_easybuild`)

.. raw:: html

  <script type="text/javascript" src="https://asciinema.org/a/88511.js" id="asciicast-88511" async></script>
