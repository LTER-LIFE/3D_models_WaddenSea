.. _demo_bootstrapping:

Demo: bootstrapping EasyBuild
=============================

(see also :ref:`bootstrapping`)

.. raw:: html

  <script type="text/javascript" src="https://asciinema.org/a/88843.js" id="asciicast-88843" async></script>
