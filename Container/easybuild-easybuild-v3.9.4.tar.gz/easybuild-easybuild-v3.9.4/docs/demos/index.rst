.. _demos:

Demos
=====

List of available demos:

* :ref:`demo_bootstrapping`
* :ref:`demo_configuring`
* :ref:`demo_review_pr`
