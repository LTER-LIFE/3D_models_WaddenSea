.. _demo_review_pr:

Demo: reviewing easyconfig pull requests with ``eb --review-pr``
================================================================

(see also :ref:`contributing_review_process_review_pr`)

.. raw:: html

  <script type="text/javascript" src="https://asciinema.org/a/103889.js" id="asciicast-103889" async></script>
